public class TestFinally {


    public static void main(String[] args) {

        System.out.println("entre a code ");
        int x = System.in.read();


        // afficher toujours le message "Thank you, goodbye."

    }

}


